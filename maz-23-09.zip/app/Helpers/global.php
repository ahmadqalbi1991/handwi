<?php
const TAX_INCLUSIVE = TRUE;
const USERTIMEZONE = 'Etc/GMT';
const TOrderStockTimeout = 3600;
define("SITE_COPYRIGHT", date('Y') . ' Ma7zouz ENTERPRISES');
const ORDER_MIN_POINT = 100;