<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Mail\SendMail;
use App\Models\CountryModel;
use App\Models\MyShop;
use App\Models\PasswordReset;
use App\Models\UserTable;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Validator;
use Auth, Session;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'user_email' => 'required|email',
                'user_password' => 'required',
                'device_cart_id' => 'required',
            ], [
                'user_email.required' => __('messages.validation.required', ['field' => __('messages.common_messages.user_email')]),
                'user_email.email' => __('messages.validation.email', ['field' => __('messages.common_messages.user_email')]),
                'user_password.required' => __('messages.validation.required', ['field' => __('messages.common_messages.user_password')]),
                'device_cart_id.required' => __('messages.validation.required', ['field' => __('messages.common_messages.device_cart_id')]),
            ]);

            if ($validator->fails()) {
                return return_response('0', 200, '', $validator->errors());
            }

            $email = $request->user_email;
            $password = $request->user_password;
            $device_cart_id = $request->device_cart_id;

            if (Auth::attempt(['user_email_id' => $email, 'password' => $password])) {
                $user_data = Auth::user();
                $access_token = $user_data->createToken('API Token')->accessToken;
                $access_token = $access_token;
                $image = asset("uploads/user/" . $user_data->image);
                if (!(file_exists($image) && is_file($image)))
                    $image = asset("images/user_dummy.png");
                $user_data->image = $image;
                $user_data->user_access_token = $access_token;

                $i_data = array(
                    'user_device_token' => trim($request->user_device_token),
                    'user_device_type' => trim($request->user_device_type),
                    'user_last_login' => Carbon::now(),
                    "login_type" => 'N'
                );

                UserTable::updateUser($i_data, $user_data->user_id);

                if (session()->has('country_id')) {
                    if ($user_data->country_id === session()->get('country_id')) {
                        process_user_cart_data($user_data->user_id, $device_cart_id);
                        $country = CountryModel::where(['country_id' => session()->get('country_id'), 'country_language_code' => 1])->first();
                    } else {
                        $country = CountryModel::where(['country_id' => $user_data->user_country_id, 'country_language_code' => 1])->first();
                        session(['country_id' => $country->id, 'currency' => $country->country_currency]);
                    }
                } else {
                    $country = CountryModel::where(['country_id' => $user_data->user_country_id, 'country_language_code' => 1])->first();
                    session(['country_id' => $country->country_id, 'currency' => $country->country_currency]);
                }

                $status = '1';
                $message = __('messages.success.login_success');
                $user_data = convertNumbersToStrings($user_data->toArray());

                return return_response($status, 200, $message, [], $user_data);
            } else {
                $status = '0';
                $message = __('messages.errors.invalid_credentials');

                return return_response($status, 200, $message);
            }
        } catch (\Exception $exception) {
            return return_response('0', 500, __('messages.errors.something_went_wrong'));
        }
    }

    public function forgetPassword(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'user_email' => 'required|email',
            ], [
                'user_email.required' => __('messages.validation.required', ['field' => __('messages.common_messages.user_email')]),
                'user_email.email' => __('messages.validation.email', ['field' => __('messages.common_messages.user_email')])
            ]);

            if ($validator->fails()) {
                return return_response('0', 200, '', $validator->errors());
            }

            $user_data = UserTable::where(['user_email_id' => $request->user_email])->first();
            if ($user_data) {
                if ($user_data->login_type == "S") {
                    $status = "3";
                    $message = __('messages.errors.user_pass_reset_social_fail');
                } else {
                    $i_data["user_id"] = $user_data->user_id;
                    $i_data["session_start_time"] = Carbon::now();
                    $current_date = strtotime($i_data['session_start_time']);
                    $future_date = $current_date + (60 * 5);
                    $format_date = date("Y-m-d H:i:s", $future_date);
                    $i_data['session_end_time'] = $format_date;
                    PasswordReset::where(['user_id' => $user_data->user_id])->delete();
                    PasswordReset::create($i_data);

                    $user_id = encryptId($user_data->user_id);
                    $link = url('/') . "reset/" . $user_id;

                    $subject = 'Reset Password';
                    $data = [
                        'user_name' => $user_data->user_first_name,
                        'link' => $link
                    ];
                    $view = 'emails.reset-password';
                    Mail::to($user_data->user_email_id)->send(new SendMail($data, $subject, $view));

                    $status = "1";
                    $message = __('messages.success.password_reset_link_sent');

                }
            } else {
                $status = "3";
                $message = __('messages.errors.no_user_found');
            }

            return return_response($status, 200, $message);
        } catch (\Exception $exception) {
            return return_response('0', 500, __('messages.errors.something_went_wrong'));
        }
    }

    public function changePassword(Request $request) {
        try {
            $validator = Validator::make($request->all(),[
                'user_id' => 'required',
                'user_old_password' => 'required|string|min:8|max:20',
                'user_new_password' => 'required|string|min:8|max:20',
            ], [
                'user_old_password.required' => __('messages.validation.required', ['field' => __('messages.common_messages.user_old_password')]),
                'user_old_password.min' => __('messages.validation.required', [
                    'field' => __('messages.common_messages.user_old_password'),
                    'min_length' => 8
                    ]),
                'user_old_password.max' => __('messages.validation.required', [
                    'field' => __('messages.common_messages.user_old_password'),
                    'max_length' => 20
                ]),

                'user_new_password.required' => __('messages.validation.required', ['field' => __('messages.common_messages.user_new_password')]),
                'user_new_password.min' => __('messages.validation.required', [
                    'field' => __('messages.common_messages.user_new_password'),
                    'min_length' => 8
                ]),
                'user_new_password.max' => __('messages.validation.required', [
                    'field' => __('messages.common_messages.user_new_password'),
                    'max_length' => 20
                ]),
                'user_id.required' => __('messages.validation.required', ['field' => __('messages.common_messages.user_id')])
            ]);

            if ($validator->fails()) {
                return return_response('0', 200, '', $validator->errors());
            }

            $user = UserTable::where('user_id', $request->user_id)->first();
            if (empty($user)) {
                return return_response('0', 200, __('messages.errors.no_user_found_token'));
            }

            if ((Hash::check($request->user_old_password, $user->user_password)) || (password_verify($request->user_old_password, $user->user_password))) {
                if (!password_verify($request->user_new_password, $user->user_password)) {
                    $data = [
                        'user_password' => bcrypt($request->user_new_password)
                    ];
                    UserTable::where('user_id', $user->user_id)->update($data);

                    $message    = __('messages.success.pwd_change_success');
                    $status     = "1";
                    $subject = 'Change Password';
                    $data = [
                        'user_name' => $user->user_first_name,
                        'email' => 'ahmadqalbi1991@gmail.com',
                    ];
                    $view = 'emails.reset-password';

                    Mail::to($user->user_email_id)->send(new SendMail($data, $subject, $view));
                } else {
                        $status = '0';
                        $message = __('messages.errors.you_cannot_use_previous_password');
                }
            } else {
                $status = '0';
                $message = __('messages.errors.incorrect_password');
            }

            return return_response($status, 200, $message, []);
        } catch (\Exception $exception) {
            return return_response('0', 500, __('messages.errors.something_went_wrong'));
        }
    }
}
