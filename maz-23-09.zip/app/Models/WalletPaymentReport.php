<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class WalletPaymentReport extends Model
{
    protected $table = "wallet_payment_report";
    protected $primaryKey = "id";
    
}