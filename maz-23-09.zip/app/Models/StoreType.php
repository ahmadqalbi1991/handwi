<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class StoreType extends Model
{
    //
    protected $table = "store_type";
    protected $primaryKey = "id";

    protected $guarded = [];

}
