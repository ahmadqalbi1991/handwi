<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class ProductMasterRequest extends Model
{
    //
    protected $table = "product_master_request";
    protected $primaryKey = "id";

    protected $guarded = [];

}
