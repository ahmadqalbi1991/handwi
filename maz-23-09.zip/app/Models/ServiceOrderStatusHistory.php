<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class ServiceOrderStatusHistory extends Model
{

    protected $table = 'service_order_status_history';
}
