<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BankCodetypes extends Model
{
    use HasFactory;
    protected $table = "bank_code_types";
    public $timestamps = false;


    
}
