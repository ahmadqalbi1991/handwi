<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StoreManagersTypes extends Model
{
    use HasFactory;
    protected $table = "store_managers_types";
    public $timestamps = false;

}
