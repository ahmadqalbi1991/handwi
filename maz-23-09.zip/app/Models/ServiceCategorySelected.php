<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class ServiceCategorySelected extends Model
{
    //
    protected $table = "service_category_selected";
    protected $primaryKey = "id";

    protected $guarded = [];



}