<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PaymentReport extends Model
{
    protected $table = "payment_report";
    protected $primaryKey = "id";
    
}