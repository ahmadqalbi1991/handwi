<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MyModa extends Model
{
    use HasFactory;
    protected $table = "my_moda";
    protected $guarded = [];
   
}
